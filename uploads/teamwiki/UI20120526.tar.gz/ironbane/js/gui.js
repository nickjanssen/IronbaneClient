$('#inventory').hover( 
  function(){
    $('#item-comparison').show();
    $('#inventory .item').hover(
      function(){
	
	$('#item-comparison').css({opacity:1});
      },function(){
	$('#item-comparison').css({opacity:0});
	
      }
    );
    

    
  },function(){
    $('#item-comparison').hide();
  }
);
$('#inventory .category h4.title').click(function(){
  $(this).parent().toggleClass('hide');
});
$('#menu .inventory').click(function(){
  $(this).toggleClass('actual');
  $('#inventory').toggleClass('hide');
});